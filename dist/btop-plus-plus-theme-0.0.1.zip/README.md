# btop++ Dark — VS Code Theme

A compact dark theme inspired by btop's teal/green accents.

## Quick install & test (VS Code Insiders)

Option A — Run in Extension Development Host (fast, no packaging):
1. Open this folder (`tools/vscode-btop-theme`) in **VS Code Insiders**.
2. Press **F5** — a new Extension Development Host window will open with the theme available.
3. In that host, open **Command Palette** (Ctrl+Shift+P) → **"Color Theme"** → choose **"btop++ Dark"**.

Option B — Package as a .vsix and install (works for Insiders and stable):
1. Package using `vsce` (no global install required):
   - `npx --yes vsce package`  
   (or `npm i -g @vscode/vsce && vsce package`)
2. The package will be created as: `btop-plus-plus-theme-0.0.1.vsix` (in this folder).
3. Install into **VS Code Insiders**:  
   - `code-insiders --install-extension ./btop-plus-plus-theme-0.0.1.vsix`  
   or into **VS Code Stable**:  
   - `code --install-extension ./btop-plus-plus-theme-0.0.1.vsix`
4. To uninstall:  
   - `code-insiders --uninstall-extension btop-plus-plus-theme`  (or `code --uninstall-extension`)

Notes and tips:
- If `vsce` warns about missing `repository` or `LICENSE`, you can ignore for local packaging or add those fields to `package.json` for publishing.
- The produced `.vsix` is already available here: `tools/vscode-btop-theme/btop-plus-plus-theme-0.0.1.vsix` (you can copy or share this file).

## Customize (quick guide)
- Workbench colors: edit `themes/btop-dark-color-theme.json` → the `colors` section.
- Syntax highlighting: edit `tokenColors` → add scopes or language-specific entries.

Example: add language-specific rules (Python / Java / JSON):
```
{
  "scope": ["source.python - comment"],
  "settings": { "foreground": "#7EE787" }
},
{
  "scope": ["source.java - comment"],
  "settings": { "foreground": "#2DD4BF" }
},
{
  "scope": ["source.json - comment"],
  "settings": { "foreground": "#C7D2D8" }
}
```

---
If you want, I can:
- add more precise token rules for Python, Java, JSON (or other languages),
- increase contrast or switch to a more pastel "catppuccin" palette, or
- upload a downloadable `.vsix` somewhere for direct download.
